package student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class SAnnouncement extends javax.swing.JFrame {

    public SAnnouncement() {
        initComponents();
        this.setTitle("Classroom Management System (Student) - Announcement");
        this.setLocationRelativeTo(null);
        showMyAnnouncement();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgcolor = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        announcementTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        announcementDescArea = new javax.swing.JTextArea();
        menubar = new javax.swing.JMenuBar();
        menuAnnouncement = new javax.swing.JMenu();
        menuAssignment = new javax.swing.JMenu();
        menuReadingResources = new javax.swing.JMenu();
        menuProfile = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bgcolor.setBackground(new java.awt.Color(153, 153, 153));

        announcementTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Name", "Title", "Description"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        announcementTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                announcementTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(announcementTable);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("Announcements!!!");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel2.setText("Announcement: ");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 204));
        jLabel3.setText("Note: Click on a row to view Announcement Description Properly");

        announcementDescArea.setColumns(20);
        announcementDescArea.setForeground(new java.awt.Color(20, 20, 20));
        announcementDescArea.setRows(5);
        announcementDescArea.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        announcementDescArea.setEnabled(false);
        jScrollPane2.setViewportView(announcementDescArea);

        javax.swing.GroupLayout bgcolorLayout = new javax.swing.GroupLayout(bgcolor);
        bgcolor.setLayout(bgcolorLayout);
        bgcolorLayout.setHorizontalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                        .addComponent(jLabel2))
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addContainerGap(284, Short.MAX_VALUE)
                        .addComponent(jLabel1)))
                .addContainerGap(284, Short.MAX_VALUE))
            .addComponent(jScrollPane2)
        );
        bgcolorLayout.setVerticalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgcolorLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        menubar.setBackground(new java.awt.Color(255, 51, 51));
        menubar.setBorder(null);
        menubar.setMargin(new java.awt.Insets(50, 50, 50, 50));

        menuAnnouncement.setBorder(null);
        menuAnnouncement.setForeground(new java.awt.Color(255, 255, 255));
        menuAnnouncement.setText("Announcement");
        menuAnnouncement.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAnnouncement.setIconTextGap(10);
        menuAnnouncement.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAnnouncementMouseClicked(evt);
            }
        });
        menubar.add(menuAnnouncement);

        menuAssignment.setBorder(null);
        menuAssignment.setForeground(new java.awt.Color(255, 255, 255));
        menuAssignment.setText("Assignment");
        menuAssignment.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAssignment.setIconTextGap(10);
        menuAssignment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAssignmentMouseClicked(evt);
            }
        });
        menubar.add(menuAssignment);

        menuReadingResources.setBorder(null);
        menuReadingResources.setForeground(new java.awt.Color(255, 255, 255));
        menuReadingResources.setText("Reading Resources");
        menuReadingResources.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuReadingResources.setIconTextGap(10);
        menuReadingResources.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReadingResourcesMouseClicked(evt);
            }
        });
        menubar.add(menuReadingResources);

        menuProfile.setBorder(null);
        menuProfile.setForeground(new java.awt.Color(255, 255, 255));
        menuProfile.setText("Profile");
        menuProfile.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuProfileMouseClicked(evt);
            }
        });
        menubar.add(menuProfile);

        setJMenuBar(menubar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    public void showMyAnnouncement() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement("select Name, Title, Description from announcement order by Id desc");
            ResultSet rs = ps.executeQuery();
            announcementTable.setModel(DbUtils.resultSetToTableModel(rs));
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void menuAnnouncementMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAnnouncementMouseClicked
        new SAnnouncement().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAnnouncementMouseClicked

    private void menuAssignmentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAssignmentMouseClicked
        new SAssignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAssignmentMouseClicked

    private void menuReadingResourcesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReadingResourcesMouseClicked
        new SReadingResources().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuReadingResourcesMouseClicked

    private void menuProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuProfileMouseClicked
        new Profile().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuProfileMouseClicked

    private void announcementTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_announcementTableMouseClicked
        DefaultTableModel model = (DefaultTableModel) announcementTable.getModel();
        int selectedRowIndex = announcementTable.getSelectedRow();

        announcementDescArea.setText(model.getValueAt(selectedRowIndex, 2).toString());
    }//GEN-LAST:event_announcementTableMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SAnnouncement().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea announcementDescArea;
    private javax.swing.JTable announcementTable;
    private javax.swing.JPanel bgcolor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JMenu menuAnnouncement;
    private javax.swing.JMenu menuAssignment;
    private javax.swing.JMenu menuProfile;
    private javax.swing.JMenu menuReadingResources;
    private javax.swing.JMenuBar menubar;
    // End of variables declaration//GEN-END:variables
}
