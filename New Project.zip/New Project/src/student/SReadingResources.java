package student;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class SReadingResources extends javax.swing.JFrame {

    public SReadingResources() {
        initComponents();
        this.setTitle("Classroom Management System (Student) - Reading Resources");
        this.setLocationRelativeTo(null);
        showMyReadingResources();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgcolor = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        readingResourcesTable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        menubar = new javax.swing.JMenuBar();
        menuAnnouncement = new javax.swing.JMenu();
        menuAssignment = new javax.swing.JMenu();
        menuReadingResources = new javax.swing.JMenu();
        menuProfile = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bgcolor.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Reading Resources");

        readingResourcesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Subject", "Title", "Download"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        readingResourcesTable.getTableHeader().setReorderingAllowed(false);
        readingResourcesTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                readingResourcesTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(readingResourcesTable);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 204));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Note: Click on a row to download Reading Resources File");

        javax.swing.GroupLayout bgcolorLayout = new javax.swing.GroupLayout(bgcolor);
        bgcolor.setLayout(bgcolorLayout);
        bgcolorLayout.setHorizontalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        bgcolorLayout.setVerticalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(4, 4, 4)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE))
        );

        menubar.setBackground(new java.awt.Color(255, 51, 51));
        menubar.setBorder(null);
        menubar.setMargin(new java.awt.Insets(50, 50, 50, 50));

        menuAnnouncement.setBorder(null);
        menuAnnouncement.setForeground(new java.awt.Color(255, 255, 255));
        menuAnnouncement.setText("Announcement");
        menuAnnouncement.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAnnouncement.setIconTextGap(10);
        menuAnnouncement.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAnnouncementMouseClicked(evt);
            }
        });
        menubar.add(menuAnnouncement);

        menuAssignment.setBorder(null);
        menuAssignment.setForeground(new java.awt.Color(255, 255, 255));
        menuAssignment.setText("Assignment");
        menuAssignment.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAssignment.setIconTextGap(10);
        menuAssignment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAssignmentMouseClicked(evt);
            }
        });
        menubar.add(menuAssignment);

        menuReadingResources.setBorder(null);
        menuReadingResources.setForeground(new java.awt.Color(255, 255, 255));
        menuReadingResources.setText("Reading Resources");
        menuReadingResources.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuReadingResources.setIconTextGap(10);
        menuReadingResources.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReadingResourcesMouseClicked(evt);
            }
        });
        menubar.add(menuReadingResources);

        menuProfile.setBorder(null);
        menuProfile.setForeground(new java.awt.Color(255, 255, 255));
        menuProfile.setText("Profile");
        menuProfile.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuProfileMouseClicked(evt);
            }
        });
        menubar.add(menuProfile);

        setJMenuBar(menubar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void showMyReadingResources() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement("select `Id`, `Subject`, `Teacher Name`, `Title`, `Files` from reading_resources order by Id desc");
            ResultSet rs = ps.executeQuery();
            readingResourcesTable.setModel(DbUtils.resultSetToTableModel(rs));
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void menuAnnouncementMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAnnouncementMouseClicked
        new SAnnouncement().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAnnouncementMouseClicked

    private void menuAssignmentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAssignmentMouseClicked
        new SAssignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAssignmentMouseClicked

    private void menuReadingResourcesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReadingResourcesMouseClicked
        new SReadingResources().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuReadingResourcesMouseClicked

    private void menuProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuProfileMouseClicked
        new Profile().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuProfileMouseClicked

    private void readingResourcesTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_readingResourcesTableMouseClicked
        DefaultTableModel model = (DefaultTableModel) readingResourcesTable.getModel();
        int selectedRowIndex = readingResourcesTable.getSelectedRow();

        int id = Integer.parseInt(model.getValueAt(selectedRowIndex, 0).toString());

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement("select `Files`, `Extension` from reading_resources where Id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                InputStream input = rs.getBinaryStream("Files");
                String ext = rs.getString("Extension");

                File theFile = new File("CMS_ReadingResources" + id + "." + ext);
                FileOutputStream output = new FileOutputStream(theFile);

                byte[] buffer = new byte[1024];
                while (input.read(buffer) > 0) {
                    output.write(buffer);
                }
                JOptionPane.showMessageDialog(rootPane, "Saved File at " + theFile.getAbsolutePath());
            }

        } catch (Exception ex) {
            Logger.getLogger(SAssignment.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_readingResourcesTableMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SReadingResources().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bgcolor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu menuAnnouncement;
    private javax.swing.JMenu menuAssignment;
    private javax.swing.JMenu menuProfile;
    private javax.swing.JMenu menuReadingResources;
    private javax.swing.JMenuBar menubar;
    private javax.swing.JTable readingResourcesTable;
    // End of variables declaration//GEN-END:variables
}
