/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Subash
 */
public class SendAssignment extends javax.swing.JFrame {

    public SendAssignment() {
        initComponents();
        this.setTitle("Classroom Management System (Student) - Send Assignment");
        this.setLocationRelativeTo(null);
        showMyAssignment();
        stdName.setText(Profile.userN);
        showCurrentDate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgcolor = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        assignmentTable = new javax.swing.JTable();
        subject = new javax.swing.JLabel();
        subjectField = new javax.swing.JTextField();
        teacherNamelbl = new javax.swing.JLabel();
        teacherName = new javax.swing.JTextField();
        assignmentTitle = new javax.swing.JLabel();
        assignmentField = new javax.swing.JTextField();
        filesImage = new javax.swing.JLabel();
        uploadbtn = new javax.swing.JButton();
        submitbtn = new javax.swing.JButton();
        filePath = new javax.swing.JLabel();
        stdName = new javax.swing.JTextField();
        teacherNamelbl1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        rolllbl = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        submittedDateChooser = new com.toedter.calendar.JDateChooser();
        menubar = new javax.swing.JMenuBar();
        menuAnnouncement = new javax.swing.JMenu();
        menuAssignment = new javax.swing.JMenu();
        menuReadingResources = new javax.swing.JMenu();
        menuProfile = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bgcolor.setBackground(new java.awt.Color(153, 153, 153));

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("Have you completed your Assignment?");

        assignmentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Subject", "Title", "Submission Date", "Download"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        assignmentTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                assignmentTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(assignmentTable);

        subject.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        subject.setText("Subject:");

        subjectField.setDisabledTextColor(new java.awt.Color(51, 51, 51));
        subjectField.setEnabled(false);
        subjectField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectFieldActionPerformed(evt);
            }
        });

        teacherNamelbl.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        teacherNamelbl.setText("To:");

        teacherName.setDisabledTextColor(new java.awt.Color(51, 51, 51));
        teacherName.setEnabled(false);
        teacherName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherNameActionPerformed(evt);
            }
        });

        assignmentTitle.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        assignmentTitle.setText("Assignment Title:");

        assignmentField.setDisabledTextColor(new java.awt.Color(51, 51, 51));
        assignmentField.setEnabled(false);

        filesImage.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        filesImage.setText("Files/Images:");

        uploadbtn.setText("UPLOAD");
        uploadbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadbtnActionPerformed(evt);
            }
        });

        submitbtn.setBackground(new java.awt.Color(255, 0, 255));
        submitbtn.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        submitbtn.setForeground(new java.awt.Color(255, 255, 255));
        submitbtn.setText("Submit");
        submitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitbtnActionPerformed(evt);
            }
        });

        stdName.setDisabledTextColor(new java.awt.Color(51, 51, 51));
        stdName.setEnabled(false);
        stdName.setMinimumSize(new java.awt.Dimension(6, 25));

        teacherNamelbl1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        teacherNamelbl1.setText("From:");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 204));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Note: Click on a row to retrieve the data in the form.");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel3.setText("Roll No:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setText("Submitted Date:");

        submittedDateChooser.setDateFormatString("yyyy-MM-d");
        submittedDateChooser.setEnabled(false);

        javax.swing.GroupLayout bgcolorLayout = new javax.swing.GroupLayout(bgcolor);
        bgcolor.setLayout(bgcolorLayout);
        bgcolorLayout.setHorizontalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(subject, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(teacherNamelbl)
                            .addComponent(assignmentTitle)
                            .addComponent(teacherNamelbl1)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(filesImage, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(subjectField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(stdName, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                .addComponent(assignmentField)
                                .addComponent(teacherName))
                            .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(submittedDateChooser, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(rolllbl, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addComponent(uploadbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(filePath, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel1)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)))
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addGap(133, 133, 133)
                .addComponent(submitbtn)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        bgcolorLayout.setVerticalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(30, 30, 30)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(teacherNamelbl1, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                                    .addComponent(stdName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(24, 24, 24)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(teacherNamelbl)
                                    .addComponent(teacherName, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(subject, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(subjectField, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(assignmentField, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(assignmentTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(submittedDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(rolllbl, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(filesImage)
                                    .addComponent(uploadbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(filePath, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addComponent(submitbtn)
                        .addGap(40, 40, 40))))
        );

        menubar.setBackground(new java.awt.Color(255, 51, 51));
        menubar.setBorder(null);
        menubar.setMargin(new java.awt.Insets(50, 50, 50, 50));

        menuAnnouncement.setBorder(null);
        menuAnnouncement.setForeground(new java.awt.Color(255, 255, 255));
        menuAnnouncement.setText("Announcement");
        menuAnnouncement.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAnnouncement.setIconTextGap(10);
        menuAnnouncement.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAnnouncementMouseClicked(evt);
            }
        });
        menubar.add(menuAnnouncement);

        menuAssignment.setBorder(null);
        menuAssignment.setForeground(new java.awt.Color(255, 255, 255));
        menuAssignment.setText("Assignment");
        menuAssignment.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAssignment.setIconTextGap(10);
        menuAssignment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAssignmentMouseClicked(evt);
            }
        });
        menubar.add(menuAssignment);

        menuReadingResources.setBorder(null);
        menuReadingResources.setForeground(new java.awt.Color(255, 255, 255));
        menuReadingResources.setText("Reading Resources");
        menuReadingResources.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuReadingResources.setIconTextGap(10);
        menuReadingResources.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReadingResourcesMouseClicked(evt);
            }
        });
        menubar.add(menuReadingResources);

        menuProfile.setBorder(null);
        menuProfile.setForeground(new java.awt.Color(255, 255, 255));
        menuProfile.setText("Profile");
        menuProfile.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuProfileMouseClicked(evt);
            }
        });
        menubar.add(menuProfile);

        setJMenuBar(menubar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void showCurrentDate() {
        int day, month, year;

//        java.util.Date date = new SimpleDateFormat("yyyy-MM-d").(new Date().toString());
//        submittedDateChooser.setDate(date);

        GregorianCalendar gc = new GregorianCalendar();
        day = gc.get(Calendar.DAY_OF_MONTH);
        month = gc.get(Calendar.MONTH);
        year = gc.get(Calendar.YEAR);
        try {
            String date = "" + year + "-" + (month + 1) + "-" + day;
            java.util.Date date2 = new SimpleDateFormat("yyyy-MM-d").parse(date);
            submittedDateChooser.setDate(date2);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void postAssignment() {
        try {
            String subjectName = subjectField.getText();
            String tName = teacherName.getText();
            String assignmentT = assignmentField.getText();
            String path = filePath.getText();
            String sName = stdName.getText();
            int roll = Integer.parseInt(rolllbl.getText());
            java.sql.Date sDate = new java.sql.Date(submittedDateChooser.getDate().getTime());
            String extension = path.split("\\.")[1];

            InputStream fin = new FileInputStream(new File(path));

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement(" insert into done_assignment (`Subject`, `Teacher Name`, `Title`, `Files`, `Extension`, `Student Username`, `Roll_No`, `Submitted Date`)" + " values(?,?,?,?,?,?,?,?)");
            ps.setString(1, subjectName);
            ps.setString(2, tName);
            ps.setString(3, assignmentT);
            ps.setBinaryStream(4, fin);
            ps.setString(5, extension);
            ps.setString(6, sName);
            ps.setInt(7, roll);
            ps.setDate(8, sDate);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(rootPane, "Assignment send to teacher successfully!");
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void showMyAssignment() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement("select `Id`, `Subject`, `Teacher Name`, `Title` from assignment order by Id desc");
            ResultSet rs = ps.executeQuery(); 
            assignmentTable.setModel(DbUtils.resultSetToTableModel(rs));
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void menuAnnouncementMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAnnouncementMouseClicked
        new SAnnouncement().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAnnouncementMouseClicked

    private void menuAssignmentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAssignmentMouseClicked
        new SAssignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAssignmentMouseClicked

    private void menuReadingResourcesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReadingResourcesMouseClicked
        new SReadingResources().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuReadingResourcesMouseClicked

    private void menuProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuProfileMouseClicked
        new Profile().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuProfileMouseClicked

    private void assignmentTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_assignmentTableMouseClicked
        DefaultTableModel model = (DefaultTableModel) assignmentTable.getModel();
        int selectedRowIndex = assignmentTable.getSelectedRow();

        teacherName.setText(model.getValueAt(selectedRowIndex, 2).toString());
        subjectField.setText(model.getValueAt(selectedRowIndex, 1).toString());
        assignmentField.setText(model.getValueAt(selectedRowIndex, 3).toString());
    }//GEN-LAST:event_assignmentTableMouseClicked

    private void subjectFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectFieldActionPerformed

    }//GEN-LAST:event_subjectFieldActionPerformed

    private void teacherNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherNameActionPerformed

    }//GEN-LAST:event_teacherNameActionPerformed

    private void uploadbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadbtnActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        String filename = f.getAbsolutePath();
        filePath.setText(filename);
    }//GEN-LAST:event_uploadbtnActionPerformed

    private void submitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitbtnActionPerformed
        postAssignment();
    }//GEN-LAST:event_submitbtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new SAssignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SendAssignment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField assignmentField;
    private javax.swing.JTable assignmentTable;
    private javax.swing.JLabel assignmentTitle;
    private javax.swing.JPanel bgcolor;
    private javax.swing.JLabel filePath;
    private javax.swing.JLabel filesImage;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu menuAnnouncement;
    private javax.swing.JMenu menuAssignment;
    private javax.swing.JMenu menuProfile;
    private javax.swing.JMenu menuReadingResources;
    private javax.swing.JMenuBar menubar;
    private javax.swing.JTextField rolllbl;
    private javax.swing.JTextField stdName;
    private javax.swing.JLabel subject;
    private javax.swing.JTextField subjectField;
    private javax.swing.JButton submitbtn;
    private com.toedter.calendar.JDateChooser submittedDateChooser;
    private javax.swing.JTextField teacherName;
    private javax.swing.JLabel teacherNamelbl;
    private javax.swing.JLabel teacherNamelbl1;
    private javax.swing.JButton uploadbtn;
    // End of variables declaration//GEN-END:variables
}
