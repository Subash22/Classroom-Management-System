package student;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Signup extends javax.swing.JFrame {

    public Signup() {
        initComponents();
        this.setTitle("Classroom Management System (Student) - Signup");
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainscreen = new javax.swing.JPanel();
        signupBackground = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblfirstName = new javax.swing.JLabel();
        lblpassword = new javax.swing.JLabel();
        firstName = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        signupButton = new javax.swing.JButton();
        lbllastName = new javax.swing.JLabel();
        lblusername = new javax.swing.JLabel();
        lastName = new javax.swing.JTextField();
        username = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        lblLogin = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainscreen.setBackground(new java.awt.Color(153, 153, 153));

        signupBackground.setBackground(new java.awt.Color(255, 51, 51));

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 32)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(225, 225, 225));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("SIGN UP");
        jLabel1.setToolTipText("");

        javax.swing.GroupLayout signupBackgroundLayout = new javax.swing.GroupLayout(signupBackground);
        signupBackground.setLayout(signupBackgroundLayout);
        signupBackgroundLayout.setHorizontalGroup(
            signupBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signupBackgroundLayout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(197, Short.MAX_VALUE))
        );
        signupBackgroundLayout.setVerticalGroup(
            signupBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        lblfirstName.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        lblfirstName.setText("First Name:");

        lblpassword.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        lblpassword.setText("Password:");

        firstName.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        firstName.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 5));

        password.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        password.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 5));

        signupButton.setBackground(new java.awt.Color(255, 7, 150));
        signupButton.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        signupButton.setForeground(new java.awt.Color(255, 255, 255));
        signupButton.setText("Sign Up");
        signupButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signupButtonMouseClicked(evt);
            }
        });

        lbllastName.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        lbllastName.setText("Last Name:");

        lblusername.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        lblusername.setText("Username:");

        lastName.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lastName.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 5));

        username.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        username.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 5));

        lblEmail.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        lblEmail.setText("Email ID:");

        email.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        email.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 5, 1, 5));

        lblLogin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLogin.setText("Already a Member! Login");
        lblLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLoginMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout mainscreenLayout = new javax.swing.GroupLayout(mainscreen);
        mainscreen.setLayout(mainscreenLayout);
        mainscreenLayout.setHorizontalGroup(
            mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(signupBackground, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(mainscreenLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(mainscreenLayout.createSequentialGroup()
                        .addComponent(lblfirstName)
                        .addGap(48, 48, 48)
                        .addComponent(firstName, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainscreenLayout.createSequentialGroup()
                        .addComponent(lblpassword)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainscreenLayout.createSequentialGroup()
                        .addComponent(lbllastName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lastName, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainscreenLayout.createSequentialGroup()
                        .addComponent(lblusername)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainscreenLayout.createSequentialGroup()
                        .addComponent(lblEmail)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(mainscreenLayout.createSequentialGroup()
                .addGap(208, 208, 208)
                .addGroup(mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(signupButton, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        mainscreenLayout.setVerticalGroup(
            mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainscreenLayout.createSequentialGroup()
                .addComponent(signupBackground, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addGroup(mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblfirstName)
                    .addComponent(firstName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbllastName)
                    .addComponent(lastName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblusername)
                    .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEmail))
                .addGap(35, 35, 35)
                .addGroup(mainscreenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblpassword)
                    .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(signupButton, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainscreen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainscreen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void signupProcess() {

        try {
            String firstname = firstName.getText();
            String lastname = lastName.getText();
            String mail = email.getText();
            String userName = username.getText();
            char passwordChar[] = password.getPassword();
            String Password = String.valueOf(passwordChar);

            if (firstname.isEmpty() || lastname.isEmpty() || mail.isEmpty() || userName.isEmpty() || Password.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Some Fields are Missing!");
            } else {

                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
                PreparedStatement ps = con.prepareStatement(" insert into user_list (firstName, lastName, email, username, password)" + " values(?,?,?,?,?)");
                ps.setString(1, firstname);
                ps.setString(2, lastname);
                ps.setString(3, mail);
                ps.setString(4, userName);
                ps.setString(5, Password);

                ps.execute();

                JOptionPane.showMessageDialog(rootPane, "Successfully Registered!");
                new Login().setVisible(true);
                dispose();
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, "Username or Email already Used!");
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void signupButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupButtonMouseClicked

        signupProcess();
    }//GEN-LAST:event_signupButtonMouseClicked

    private void lblLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLoginMouseClicked
        new Login().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_lblLoginMouseClicked

    private void signupButtonMouseEntered(java.awt.event.MouseEvent evt) {

        signupButton.setBackground(new Color(255, 51, 51));
        signupButton.setBorder(null);
    }

    private void signupButtonMouseExited(java.awt.event.MouseEvent evt) {

        signupButton.setBackground(new Color(255, 7, 150));
    }

    private void lblLoginMouseEntered(java.awt.event.MouseEvent evt) {

        lblLogin.setForeground(new Color(72, 52, 223));
    }

    private void lblLoginMouseExited(java.awt.event.MouseEvent evt) {

        lblLogin.setForeground(new Color(0, 0, 0));
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Signup().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField email;
    private javax.swing.JTextField firstName;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField lastName;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblLogin;
    private javax.swing.JLabel lblfirstName;
    private javax.swing.JLabel lbllastName;
    private javax.swing.JLabel lblpassword;
    private javax.swing.JLabel lblusername;
    private javax.swing.JPanel mainscreen;
    private javax.swing.JPasswordField password;
    private javax.swing.JPanel signupBackground;
    private javax.swing.JButton signupButton;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
