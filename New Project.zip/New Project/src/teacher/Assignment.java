package teacher;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.time.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import student.Login;

public class Assignment extends javax.swing.JFrame {

    public Assignment() {
        initComponents();
        this.setTitle("Classroom Management System (Teacher) - Assignment");
        this.setLocationRelativeTo(null);
        showMyAssignment();
        teacherName.setText(TLogin.userN);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgcolor = new javax.swing.JPanel();
        dbName = new javax.swing.JLabel();
        greetUserlbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        subject = new javax.swing.JLabel();
        subjectField = new javax.swing.JTextField();
        teacherNamelbl = new javax.swing.JLabel();
        teacherName = new javax.swing.JTextField();
        assignmentTitle = new javax.swing.JLabel();
        submissionDate = new javax.swing.JLabel();
        assignmentField = new javax.swing.JTextField();
        filesImage = new javax.swing.JLabel();
        uploadbtn = new javax.swing.JButton();
        submitbtn = new javax.swing.JButton();
        filePath = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        assignmentTable = new javax.swing.JTable();
        refreshbtn = new javax.swing.JButton();
        checkAssignment = new javax.swing.JButton();
        submissionDateChooser = new com.toedter.calendar.JDateChooser();
        menubar = new javax.swing.JMenuBar();
        menuAssignment = new javax.swing.JMenu();
        menuAnnouncement = new javax.swing.JMenu();
        menuReadingResources = new javax.swing.JMenu();
        menuReport = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bgcolor.setBackground(new java.awt.Color(153, 153, 153));

        dbName.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        dbName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        greetUserlbl.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        greetUserlbl.setForeground(new java.awt.Color(255, 255, 255));
        greetUserlbl.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("Do you want to post the Assignment?");

        subject.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        subject.setText("Subject:");

        subjectField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectFieldActionPerformed(evt);
            }
        });

        teacherNamelbl.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        teacherNamelbl.setText("Name:");

        teacherName.setDisabledTextColor(new java.awt.Color(51, 51, 51));
        teacherName.setEnabled(false);
        teacherName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherNameActionPerformed(evt);
            }
        });

        assignmentTitle.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        assignmentTitle.setText("Assignment Title:");

        submissionDate.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        submissionDate.setText("Submission Date:");

        filesImage.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        filesImage.setText("Files/Images:");

        uploadbtn.setText("UPLOAD");
        uploadbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadbtnActionPerformed(evt);
            }
        });

        submitbtn.setBackground(new java.awt.Color(255, 0, 255));
        submitbtn.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        submitbtn.setForeground(new java.awt.Color(255, 255, 255));
        submitbtn.setText("Submit");
        submitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitbtnActionPerformed(evt);
            }
        });

        assignmentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Subject", "Title", "Submission Date", "Download"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        assignmentTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                assignmentTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(assignmentTable);

        refreshbtn.setText("Refresh");
        refreshbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshbtnActionPerformed(evt);
            }
        });

        checkAssignment.setText("Check Assignment");
        checkAssignment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkAssignmentActionPerformed(evt);
            }
        });

        submissionDateChooser.setDateFormatString("yyyy-MM-d");

        javax.swing.GroupLayout bgcolorLayout = new javax.swing.GroupLayout(bgcolor);
        bgcolor.setLayout(bgcolorLayout);
        bgcolorLayout.setHorizontalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(greetUserlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGap(179, 179, 179)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addComponent(uploadbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(filePath, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(subjectField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(teacherName, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(submissionDateChooser, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(assignmentField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))))
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(subject, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(submissionDate)
                            .addComponent(filesImage)
                            .addComponent(assignmentTitle)
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addComponent(teacherNamelbl)
                                .addGap(218, 218, 218)
                                .addComponent(dbName))
                            .addComponent(jLabel1)))
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(submitbtn)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgcolorLayout.createSequentialGroup()
                        .addComponent(checkAssignment)
                        .addGap(32, 32, 32)
                        .addComponent(refreshbtn)
                        .addGap(35, 35, 35))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        bgcolorLayout.setVerticalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgcolorLayout.createSequentialGroup()
                .addComponent(greetUserlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dbName, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(33, 33, 33)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(teacherNamelbl)
                                    .addComponent(teacherName, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(33, 33, 33)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(subject, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(subjectField, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(assignmentTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(assignmentField, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(submissionDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(submissionDateChooser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(36, 36, 36)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(filesImage)
                                .addComponent(uploadbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(filePath, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(submitbtn))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(refreshbtn)
                    .addComponent(checkAssignment))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        menubar.setBackground(new java.awt.Color(255, 51, 51));
        menubar.setBorder(null);
        menubar.setMargin(new java.awt.Insets(50, 50, 50, 50));

        menuAssignment.setBorder(null);
        menuAssignment.setForeground(new java.awt.Color(255, 255, 255));
        menuAssignment.setText("Assignment");
        menuAssignment.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAssignment.setIconTextGap(10);
        menuAssignment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAssignmentMouseClicked(evt);
            }
        });
        menubar.add(menuAssignment);

        menuAnnouncement.setBorder(null);
        menuAnnouncement.setForeground(new java.awt.Color(255, 255, 255));
        menuAnnouncement.setText("Announcement");
        menuAnnouncement.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAnnouncement.setIconTextGap(10);
        menuAnnouncement.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAnnouncementMouseClicked(evt);
            }
        });
        menubar.add(menuAnnouncement);

        menuReadingResources.setBorder(null);
        menuReadingResources.setForeground(new java.awt.Color(255, 255, 255));
        menuReadingResources.setText("Reading Resources");
        menuReadingResources.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuReadingResources.setIconTextGap(10);
        menuReadingResources.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReadingResourcesMouseClicked(evt);
            }
        });
        menubar.add(menuReadingResources);

        menuReport.setBorder(null);
        menuReport.setForeground(new java.awt.Color(255, 255, 255));
        menuReport.setText("Report");
        menuReport.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuReport.setIconTextGap(10);
        menuReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReportMouseClicked(evt);
            }
        });
        menubar.add(menuReport);

        setJMenuBar(menubar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void postAssignment() {
        try {
            String subjectName = subjectField.getText();
            String tName = teacherName.getText();
            String assignmentT = assignmentField.getText();
            java.sql.Date sDate = new java.sql.Date(submissionDateChooser.getDate().getTime());
            String path = filePath.getText();
            String extension = path.split("\\.")[1];
            
            InputStream fin=new FileInputStream(new File(path));
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement(" insert into assignment (`Subject`, `Teacher Name`, `Title`, `Submission Date`, `Files`, `Extension`)" + " values(?,?,?,?,?,?)");
            ps.setString(1, subjectName);
            ps.setString(2, tName);
            ps.setString(3, assignmentT);
            ps.setDate(4, sDate);
            ps.setBinaryStream(5, fin); 
            ps.setString(6, extension);
            
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(rootPane, "Assignment posted successfully!");
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void showMyAssignment() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement("select `Subject`, `Teacher Name`, `Title`, `Submission Date` from assignment order by Id desc");
            ResultSet rs = ps.executeQuery();
            assignmentTable.setModel(DbUtils.resultSetToTableModel(rs));
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void menuAssignmentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAssignmentMouseClicked
        new Assignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAssignmentMouseClicked

    private void menuAnnouncementMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAnnouncementMouseClicked
        new Announcement().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAnnouncementMouseClicked

    private void menuReadingResourcesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReadingResourcesMouseClicked
        new ReadingResources().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuReadingResourcesMouseClicked

    private void menuReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReportMouseClicked
        new Report().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuReportMouseClicked

    private void subjectFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_subjectFieldActionPerformed

    private void teacherNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherNameActionPerformed

    private void uploadbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadbtnActionPerformed
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        String filename = f.getAbsolutePath();
        filePath.setText(filename);

    }//GEN-LAST:event_uploadbtnActionPerformed

    private void submitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitbtnActionPerformed
        postAssignment();
    }//GEN-LAST:event_submitbtnActionPerformed

    private void assignmentTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_assignmentTableMouseClicked
        
    }//GEN-LAST:event_assignmentTableMouseClicked

    private void refreshbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshbtnActionPerformed
        new Assignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_refreshbtnActionPerformed

    private void checkAssignmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkAssignmentActionPerformed
        new CheckAssignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_checkAssignmentActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Assignment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField assignmentField;
    private javax.swing.JTable assignmentTable;
    private javax.swing.JLabel assignmentTitle;
    private javax.swing.JPanel bgcolor;
    private javax.swing.JButton checkAssignment;
    private javax.swing.JLabel dbName;
    private javax.swing.JLabel filePath;
    private javax.swing.JLabel filesImage;
    private javax.swing.JLabel greetUserlbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu menuAnnouncement;
    private javax.swing.JMenu menuAssignment;
    private javax.swing.JMenu menuReadingResources;
    private javax.swing.JMenu menuReport;
    private javax.swing.JMenuBar menubar;
    private javax.swing.JButton refreshbtn;
    private javax.swing.JLabel subject;
    private javax.swing.JTextField subjectField;
    private javax.swing.JLabel submissionDate;
    private com.toedter.calendar.JDateChooser submissionDateChooser;
    private javax.swing.JButton submitbtn;
    private javax.swing.JTextField teacherName;
    private javax.swing.JLabel teacherNamelbl;
    private javax.swing.JButton uploadbtn;
    // End of variables declaration//GEN-END:variables
}
