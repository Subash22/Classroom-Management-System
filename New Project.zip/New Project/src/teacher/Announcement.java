package teacher;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
import student.Login;
import student.SAnnouncement;

public class Announcement extends javax.swing.JFrame {

    public Announcement() {
        initComponents();
        this.setTitle("Classroom Management System (Teacher) - Announcement");
        this.setLocationRelativeTo(null);
        showMyAnnouncement();
        nameField.setText(TLogin.userN);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgcolor = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        namelbl = new javax.swing.JLabel();
        titlelbl = new javax.swing.JLabel();
        descriptionlbl = new javax.swing.JLabel();
        nameField = new javax.swing.JTextField();
        titleField = new javax.swing.JTextField();
        submitbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        descArea = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        announcementTable = new javax.swing.JTable();
        refreshbtn = new javax.swing.JButton();
        menubar = new javax.swing.JMenuBar();
        menuAssignment = new javax.swing.JMenu();
        menuAnnouncement = new javax.swing.JMenu();
        menuReadingResources = new javax.swing.JMenu();
        menuReport = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bgcolor.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("Announcement!!!");

        namelbl.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        namelbl.setText("Name:");

        titlelbl.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        titlelbl.setText("Title:");

        descriptionlbl.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        descriptionlbl.setText("Description:");

        nameField.setDisabledTextColor(new java.awt.Color(51, 51, 51));
        nameField.setEnabled(false);

        submitbtn.setBackground(new java.awt.Color(255, 0, 255));
        submitbtn.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        submitbtn.setForeground(new java.awt.Color(255, 255, 255));
        submitbtn.setText("Submit");
        submitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitbtnActionPerformed(evt);
            }
        });

        descArea.setColumns(20);
        descArea.setRows(5);
        jScrollPane1.setViewportView(descArea);

        announcementTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Name", "Title", "Description"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(announcementTable);

        refreshbtn.setText("Refresh");
        refreshbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bgcolorLayout = new javax.swing.GroupLayout(bgcolor);
        bgcolor.setLayout(bgcolorLayout);
        bgcolorLayout.setHorizontalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addGap(79, 79, 79)
                                .addComponent(jLabel1))
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(namelbl)
                                    .addComponent(titlelbl)
                                    .addComponent(descriptionlbl))
                                .addGap(40, 40, 40)
                                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(nameField)
                                    .addComponent(titleField)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)))))
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(submitbtn)))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgcolorLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(refreshbtn)
                .addGap(35, 35, 35))
        );
        bgcolorLayout.setVerticalGroup(
            bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgcolorLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(refreshbtn)
                        .addContainerGap(22, Short.MAX_VALUE))
                    .addGroup(bgcolorLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(40, 40, 40)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(namelbl)
                            .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(titlelbl)
                            .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(bgcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(descriptionlbl))
                            .addGroup(bgcolorLayout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(submitbtn)
                        .addGap(96, 96, 96))))
        );

        menubar.setBackground(new java.awt.Color(255, 51, 51));
        menubar.setBorder(null);
        menubar.setMargin(new java.awt.Insets(50, 50, 50, 50));

        menuAssignment.setBorder(null);
        menuAssignment.setForeground(new java.awt.Color(255, 255, 255));
        menuAssignment.setText("Assignment");
        menuAssignment.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAssignment.setIconTextGap(10);
        menuAssignment.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAssignmentMouseClicked(evt);
            }
        });
        menubar.add(menuAssignment);

        menuAnnouncement.setBorder(null);
        menuAnnouncement.setForeground(new java.awt.Color(255, 255, 255));
        menuAnnouncement.setText("Announcement");
        menuAnnouncement.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuAnnouncement.setIconTextGap(10);
        menuAnnouncement.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAnnouncementMouseClicked(evt);
            }
        });
        menubar.add(menuAnnouncement);

        menuReadingResources.setBorder(null);
        menuReadingResources.setForeground(new java.awt.Color(255, 255, 255));
        menuReadingResources.setText("Reading Resources");
        menuReadingResources.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuReadingResources.setIconTextGap(10);
        menuReadingResources.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReadingResourcesMouseClicked(evt);
            }
        });
        menubar.add(menuReadingResources);

        menuReport.setBorder(null);
        menuReport.setForeground(new java.awt.Color(255, 255, 255));
        menuReport.setText("Report");
        menuReport.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        menuReport.setIconTextGap(10);
        menuReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReportMouseClicked(evt);
            }
        });
        menubar.add(menuReport);

        setJMenuBar(menubar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bgcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void postAnnouncement() {

        try {
            String teacherName = nameField.getText();
            String announceTitle = titleField.getText();
            String announceDesc = descArea.getText();

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement("insert into announcement (Name, Title, Description)" + " values(?,?,?)");
            ps.setString(1, teacherName);
            ps.setString(2, announceTitle);
            ps.setString(3, announceDesc);

            ps.execute();
            
            JOptionPane.showMessageDialog(rootPane, "Announcement posted successfully!");
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void showMyAnnouncement() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement ps = con.prepareStatement("select Name, Title, Description from announcement order by Id desc");
            ResultSet rs = ps.executeQuery();
            announcementTable.setModel(DbUtils.resultSetToTableModel(rs));
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void menuAssignmentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAssignmentMouseClicked
        new Assignment().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAssignmentMouseClicked

    private void menuAnnouncementMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAnnouncementMouseClicked
        new Announcement().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuAnnouncementMouseClicked

    private void menuReadingResourcesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReadingResourcesMouseClicked
        new ReadingResources().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuReadingResourcesMouseClicked

    private void menuReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReportMouseClicked
        new Report().setVisible(true);
        dispose();
    }//GEN-LAST:event_menuReportMouseClicked

    private void submitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitbtnActionPerformed
        postAnnouncement();
    }//GEN-LAST:event_submitbtnActionPerformed

    private void refreshbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshbtnActionPerformed
        new Announcement().setVisible(true);
        dispose();
    }//GEN-LAST:event_refreshbtnActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Announcement().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable announcementTable;
    private javax.swing.JPanel bgcolor;
    private javax.swing.JTextArea descArea;
    private javax.swing.JLabel descriptionlbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JMenu menuAnnouncement;
    private javax.swing.JMenu menuAssignment;
    private javax.swing.JMenu menuReadingResources;
    private javax.swing.JMenu menuReport;
    private javax.swing.JMenuBar menubar;
    private javax.swing.JTextField nameField;
    private javax.swing.JLabel namelbl;
    private javax.swing.JButton refreshbtn;
    private javax.swing.JButton submitbtn;
    private javax.swing.JTextField titleField;
    private javax.swing.JLabel titlelbl;
    // End of variables declaration//GEN-END:variables
}
